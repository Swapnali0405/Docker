package com.example.services;

import java.util.List;

import com.example.Dto.TicketDto;
import com.example.entities.Status;

public interface TicketService {
	
	
	public TicketDto createTicket(TicketDto ticketdto);
	
	public TicketDto updateTicketDetails(TicketDto ticketdto, int id);
	
	public List<TicketDto> fetchAllOpen(String status);
	
	public TicketDto fetchbyid(int id);

}
