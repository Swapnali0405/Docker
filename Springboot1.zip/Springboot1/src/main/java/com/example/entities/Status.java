package com.example.entities;

public enum Status {
	OPEN,INPROGRESS,RESOLVED
}
