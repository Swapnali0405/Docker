package com.example.entities;

public enum Category {
	SIM,CALLING,BRODBAND
}
