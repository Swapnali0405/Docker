package com.example.entities;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Tickets")
public class Ticket {
	
	@Id
	@GeneratedValue(generator = "increment")
	@Column(name="id")
	int id;
	
	
	@Column(name="phoneno")
	String phonno;
	
	@Enumerated(EnumType.STRING)
	@Column(name="category")
	Category category;
	
	@Column(name="issuedetails")
	String issudetails;
	
	@Column(name="resolutiondetails")
	String resolutiondetails;
	
	@Enumerated(EnumType.STRING)
	@Column(name="status")
	Status status;
	
	@Column(name="createdatetime")
	LocalDateTime createdatetime;
	
	@Column(name="resolutiondatetime")
	LocalDateTime resolutiondatetime;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPhonno() {
		return phonno;
	}

	public void setPhonno(String phonno) {
		this.phonno = phonno;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getIssudetails() {
		return issudetails;
	}

	public void setIssudetails(String issudetails) {
		this.issudetails = issudetails;
	}

	public String getResolutiondetails() {
		return resolutiondetails;
	}

	public void setResolutiondetails(String resolutiondetails) {
		this.resolutiondetails = resolutiondetails;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public LocalDateTime getCreatedatetime() {
		return createdatetime;
	}

	public void setCreatedatetime(LocalDateTime createdatetime) {
		this.createdatetime = createdatetime;
	}

	public LocalDateTime getResolutiondatetime() {
		return resolutiondatetime;
	}

	public void setResolutiondatetime(LocalDateTime resolutiondatetime) {
		this.resolutiondatetime = resolutiondatetime;
	}


}
